This is player moving up images
