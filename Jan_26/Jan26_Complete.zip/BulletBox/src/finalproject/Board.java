package finalproject;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Board extends JPanel implements ActionListener {
    private Timer timer;
    private Player God;
    private Level currentLevel;
    private Projectile impShot;
    private final int DELAY = 10;
    double time = 0;

    public Board(int level) {
        initBoard();
        if (level == 0){
        currentLevel = new Level(Entity.class.getResourceAsStream("level0.txt"));
        } else {
        currentLevel = new Level(Entity.class.getResourceAsStream("level1.txt"));
        }
    }

    private void initBoard() {
        addKeyListener(new TAdapter());
        setBackground(Color.black);
        setFocusable(true);
        
        gameInit();
        
        timer = new Timer(DELAY, this);
        timer.start();
    }

    private void gameInit() {
        God = new Player(400, 300);
        currentLevel = new Level(Entity.class.getResourceAsStream("level0.txt"));

    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        doDrawing(g);
        
        Toolkit.getDefaultToolkit().sync();
    }

    private void doDrawing(Graphics g) {
        Projectile temp;
        Graphics2D g2d = (Graphics2D) g;
        for (int i = 0; i < currentLevel.getArrayWidth(); i++){
            for(int j = 0; j < currentLevel.getArrayHeight(); j++){
                
                g2d.drawImage(currentLevel.findTile(i,j).getImage(), ((int)currentLevel.findTile(i,j).getX()) - ((int)God.getX()) + 400, ((int)currentLevel.findTile(i,j).getY()) - ((int)God.getY()) + 300, this);
            }
        }
        currentLevel.updateEnemies(God);
        for (int i = 0; i<currentLevel.getEnemyNumber(); i++){
            g2d.drawImage(currentLevel.findEnemy(i).getImage(), (int)currentLevel.findEnemy(i).getX() - (int)God.getX() + 400, (int)currentLevel.findEnemy(i).getY() - (int)God.getY() + 300, this);
            for (int j = 0; j<currentLevel.findEnemy(i).getProjectileNumber(); j++){
                temp = currentLevel.findEnemy(i).findProjectile(j);
                g2d.drawImage(temp.getImage(),(int)temp.getX() - (int)God.getX() + 400, (int)temp.getY() - (int)God.getY() + 300, this);

                g2d.drawRect((int)temp.getHitX() - (int)God.getX() + 400, (int)temp.getHitY() - (int)God.getY() + 300, (int)temp.getHitBox().getWidth(), (int)temp.getHitBox().getHeight());
            }
        }
        
        int health = God.getHealth();
        
        for (int i = 0; i < health; i++) {
            g2d.drawImage(SpriteSheet.heart.getImage(), 50 + i * 50, 20, this);
            
        }
        
        g2d.drawRect((int)God.getHitX() - (int)God.getX() + 400, (int)God.getHitY() - (int)God.getY() + 300, (int)God.getHitBox().getWidth(), (int)God.getHitBox().getHeight());
      
        g2d.drawImage(God.getImage(), 400, 300, this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        step();
    }
    
    private void step() {
        
        God.move(currentLevel);

        
        repaint(0, 0, 800, 600);     
    }

    private class TAdapter extends KeyAdapter {

        @Override
        public void keyReleased(KeyEvent e) {
            God.keyReleased(e);
        }

        @Override
        public void keyPressed(KeyEvent e) {
            God.keyPressed(e);
        }
    } 
}
