/*
 * Nathan Smith
 * January 26, 2022
 * Slime class to create slime objects
 */
package finalproject;

import java.net.URL;
import javax.swing.ImageIcon;

public class Slime extends Enemy{
    private int phase = 1;
    private int frameDelay, frameCounter;
    private int rotationRadius;
    private double rotationAmount = 0;
    private double initialAngle, rotationX, rotationY;
    private static URL url = Entity.class.getResource("slime.png");
    private static ImageIcon ii = new ImageIcon(url);
    
    public Slime(double x, double y, int rotationRadius, int frameDelay){
        super(x,y,50,50);
        rotationX = x;
        rotationY = y;
        this.frameDelay = frameDelay;
        frameCounter = frameDelay;
        this.rotationRadius = rotationRadius;
        imgPlayer = ii.getImage();
    }
    
    public void attack(){
        if (phase == 0){
            if (frameCounter <= 0){
                for(int i = 0; i<3; i++){
                    projectiles.add(new Projectile(x,y,Math.cos(initialAngle + (i*(2*Math.PI/3))), Math.sin(initialAngle + (i*(2*Math.PI/3)))));
                }
                initialAngle+=(10*Math.PI)/180;
                frameCounter = frameDelay;
            } else {
                frameCounter--;
            }
        } else {

                setX(rotationX + (Math.cos(rotationAmount) * rotationRadius));
                setY(rotationY + (Math.sin(rotationAmount) * rotationRadius));
                rotationAmount+=(2*Math.PI)/(rotationRadius*2);

            if (frameCounter <= 0){
                for (int i = 0; i<8; i++){
                    projectiles.add(new Projectile(x,y,Math.cos(45* i * Math.PI /180), Math.sin(45* i * Math.PI /180)));
                }
                frameCounter = frameDelay;
            } else {
                frameCounter--;
            }
            
        }
    }
    
    public int getPhase(){
        return phase;
    }
    
    public Slime clone(){
        Slime clone = new Slime(x,y,rotationRadius,frameDelay);
        return clone;
    }
    
    public boolean equals(Slime otherSlime){
        return (super.equals(otherSlime) && rotationRadius == otherSlime.rotationRadius && frameDelay == otherSlime.frameDelay);
    }
    
    public String toString(){
        return "\nSlime: " + super.toString() + "\nRotation Radius: " + rotationRadius + "\nFrame Delay: " + frameDelay;
    }
    
    
}
