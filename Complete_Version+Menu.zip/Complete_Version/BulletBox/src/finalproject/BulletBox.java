package finalproject;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class BulletBox extends JFrame implements ActionListener {

    private static GameWindow level;
    private static final long serialVersionUID = 1L;
    private final JFrame frame = new JFrame();

    public BulletBox() {
        JFrame.setDefaultLookAndFeelDecorated(true);
                
        JPanel panel = new JPanel();
        BoxLayout boxlayout = new BoxLayout(panel, BoxLayout.Y_AXIS);
        panel.setLayout(boxlayout);
        panel.setBorder(new EmptyBorder(new Insets(200, 350, 0, 0)));
        panel.setBorder(BorderFactory.createTitledBorder("Bullet Box"));
        
        JButton button1 = new JButton("Play");
        JButton button2 = new JButton("Tutorial");
        JButton button3 = new JButton("Exit");
        
        
        button1.setAlignmentX(Component.CENTER_ALIGNMENT);
        button2.setAlignmentX(Component.CENTER_ALIGNMENT);
        button3.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        //set action listeners for buttons
        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        
        //add buttons to the frame
        panel.add(button1);
        panel.add(button2);
        panel.add(button3);
        
        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
        frame.setTitle("Bullet Box");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String action = ae.getActionCommand();
        if (action.equals("Play")) {
            //check if the second window
            //has already been created
            if (level == null) {
                level = new GameWindow(this);
            }
            //set the other window to be visible
            level.setVisible(true);
            //hide this window
            frame.setVisible(false);
        } else if (action.equals("Exit")) {
            System.exit(0);
        } else if (action.equals("Tutorial")) {
            System.out.println("Test");
        }
    }
    
    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new BulletBox();
            }
        });
    }

}