package finalproject;

import javax.swing.JFrame;

public class OptionsWindow extends JFrame {

    public static GameWindow level;
    
    public OptionsWindow(GameWindow m) {
        initUI();   
        level = m;
    }
    
    private void initUI() {

        setTitle("Bullet Box");
        setSize(800, 600);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
    }
}
