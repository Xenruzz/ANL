/*
 * Nathan Smith
 * January 25, 2022
 * Turret class to create turret objects
 */
package finalproject;

public class Turret extends Enemy{
    private double direction;
    public Turret(int x, int y, int w, int h, double direction){
        super(x,y,w,h);
        this.direction = direction;
    }
    
    public double getDirection(){
        return direction;
    }
    
    
    
    public void attack(){
        projectiles.add(new Projectile(x,y,Math.cos(direction)*2, Math.sin(direction)*2));
    }
    
    public Turret clone(){
        Turret clone = new Turret(x,y,w,h,direction);
        return clone;
    }
    
    public boolean equals(Turret otherTurret){
        return(super.equals(otherTurret) && direction == otherTurret.direction);
    }
    
    public String toString(){
        return "\nTurret: " + super.toString() + "\nDirection: " + direction;
    }
}