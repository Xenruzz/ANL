Images of the player moving left
