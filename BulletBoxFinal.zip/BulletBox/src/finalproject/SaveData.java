package finalproject;


public class SaveData {
    
    int score;
    String name;
    
    public SaveData(int s, String n) {
        score = s;
        name = n;
    }
    
    public int getScore() {
        return score;
    }
    
    public String getName() {
        return name;
    }
    
    @Override
    public String toString(){
        return "Name: " + name + "\nScore: " + score + "\n";
    }
    
    public boolean equals(SaveData otherData) {
        return (score == otherData.score && name.equalsIgnoreCase(otherData.name));
    }
    
    public SaveData clone() {
        SaveData clone = new SaveData(score, name);
        return clone;
    }
    
}
