package finalproject;

import javax.swing.*;

public class GameWindow extends JFrame {

    public static BulletBox menu;
    public static LevelSelect levels;

    public GameWindow(BulletBox m, LevelSelect l, int level) {
        initUI(level);
        levels = l;
        menu = m;
    }

    private void initUI(int level) {
        add(new Game(level));

        setTitle("Bullet Box");
        setSize(800, 600);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
    }
}
