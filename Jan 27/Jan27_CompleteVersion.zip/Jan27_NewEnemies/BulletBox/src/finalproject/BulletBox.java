package finalproject;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class BulletBox extends JFrame implements ActionListener {

    private static GameWindow level;
    private static LevelSelect levels;
    private static final long serialVersionUID = 1L;

    private BufferedImage image;

    class ImagePanel extends JComponent {

        private Image image;

        public ImagePanel(Image image) {
            this.image = image;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(image, 0, 0, this);
        }
    }

    public BulletBox() {
        try {
            image = ImageIO.read(new File("src/finalproject/mainmenu.png"));
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        JFrame.setDefaultLookAndFeelDecorated(true);

        JPanel panel = new JPanel();
        
        setContentPane(new ImagePanel(image));
        BoxLayout boxlayout = new BoxLayout(panel, BoxLayout.Y_AXIS);
        panel.setLayout(boxlayout);
        panel.setBorder(new EmptyBorder(new Insets(200, 350, 0, 0)));
        panel.setBorder(BorderFactory.createTitledBorder("Bullet Box"));

        JButton button1 = new JButton("Play");
        JButton button2 = new JButton("Tutorial");
        JButton button3 = new JButton("Exit");

        button1.setAlignmentX(Component.CENTER_ALIGNMENT);
        button2.setAlignmentX(Component.CENTER_ALIGNMENT);
        button3.setAlignmentX(Component.CENTER_ALIGNMENT);

        button1.setFont(new Font("Arial", Font.BOLD, 40));
        button2.setFont(new Font("Arial", Font.BOLD, 40));
        button3.setFont(new Font("Arial", Font.BOLD, 40));

        //set action listeners for buttons
        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        add(panel);
        //add buttons to the frame
        //with spaces
        button1.setBounds(300, 250, 200, 50);
        button2.setBounds(300, 330, 200, 50);
        button3.setBounds(300, 410, 200, 50);
        add(button1);
        add(button2);
        add(button3);

        //add menu panel to frame, and make frame
        pack();
        setVisible(true);
        setTitle("Bullet Box");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String action = ae.getActionCommand();
        if (action.equals("Play")) {
            //check if the second window
            //has already been created
            if (levels == null) {
                levels = new LevelSelect(this);
            }
            //set the other window to be visible
            levels.setVisible(true);
            //hide this window
            setVisible(false);
        } else if (action.equals("Exit")) {
            System.exit(0);
        } else if (action.equals("Tutorial")) {
            if (level == null) {
                level = new GameWindow(this, levels, 0);
            }
            //set the other window to be visible
            level.setVisible(true);
            //hide this window
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new BulletBox();
            }
        });
    }

}
