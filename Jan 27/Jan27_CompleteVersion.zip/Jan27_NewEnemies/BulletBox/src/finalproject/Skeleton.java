/*
 * Nathan Smith
 * January 26, 2022
 * Skeleton class to create skeleton objects
 */
package finalproject;

import java.net.URL;
import javax.swing.ImageIcon;

public class Skeleton extends Enemy{
    
    private static URL url = Entity.class.getResource("skeleton.png");
    private static ImageIcon ii = new ImageIcon(url);
    private int frameDelay, frameCounter;
    private double aimAngle;
    
    public Skeleton(double x, double y, int frameDelay){
         
         super(x,y,ii.getIconWidth(),ii.getIconHeight());
         imgPlayer = ii.getImage();
         this.frameDelay = frameDelay;
         frameCounter = frameDelay;
         enemyType = 2;
    }
    
    public void attack(){
        double shotAngle;
        if (frameCounter <= 0){
            for(int i = 0; i<3; i++){
                shotAngle = aimAngle + (((Math.random()*2-1)* 10)*Math.PI)/180;
                System.out.println(shotAngle);
                projectiles.add(new Projectile(x,y, Math.cos(shotAngle)*4, Math.sin(shotAngle)*4));
            }
            frameCounter = frameDelay;
        } else {
            frameCounter --;
        }
    }
    
    public void chase(Player p, Level l){
        
        aimAngle = Math.atan2( p.getY() - y,  p.getX() - x);
        x = x + (Math.cos(aimAngle) * 1.5);
        hitX = hitX + (Math.cos(aimAngle) * 1.5);
        if (l.checkWall(this) == true){
            x = x - (Math.cos(aimAngle) * 1.5);
            hitX = hitX - (Math.cos(aimAngle) * 1.5);
        }
        y = y + (Math.sin(aimAngle) * 1.5);
        hitY = hitY + (Math.sin(aimAngle) * 1.5);
        if (l.checkWall(this) == true){
            y = y - (Math.sin(aimAngle) * 1.5);
            hitY = hitY - (Math.sin(aimAngle) * 1.5);
        }
    }
    
    public Skeleton clone(){
        Skeleton clone = new Skeleton(x,y,frameDelay);
        return clone;
    }
    
    public boolean equals(Skeleton otherSkeleton){
        return (super.equals(otherSkeleton) && frameDelay == otherSkeleton.frameDelay);
    }
    
    public String toString(){
        return "\nSkeleton: " + super.toString() + "\nFrame Delay: " + frameDelay;
    }
}
