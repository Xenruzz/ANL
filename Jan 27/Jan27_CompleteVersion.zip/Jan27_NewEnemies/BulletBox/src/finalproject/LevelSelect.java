
package finalproject;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class LevelSelect extends JFrame implements ActionListener {
    public static BulletBox menu;
    private static GameWindow level;
     
    public LevelSelect(BulletBox m) {
        initUI();   
        menu = m;
    }

    private void initUI() {
        JFrame.setDefaultLookAndFeelDecorated(true);
                
        JPanel panel = new JPanel();
        //BoxLayout boxlayout = new BoxLayout(panel, BoxLayout.Y_AXIS);
        //panel.setLayout(boxlayout);
        panel.setBorder(new EmptyBorder(new Insets(200, 350, 0, 0)));
        panel.setBorder(BorderFactory.createTitledBorder("Bullet Box"));
        
        JButton button1 = new JButton("Level 1");
        JButton button2 = new JButton("Level 2");
        JButton button3 = new JButton("Level 3");
        
        
        button1.setAlignmentX(Component.CENTER_ALIGNMENT);
        button2.setAlignmentX(Component.CENTER_ALIGNMENT);
        button3.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        button1.setFont(new Font("Arial", Font.BOLD, 40));
        button2.setFont(new Font("Arial", Font.BOLD, 40));
        button3.setFont(new Font("Arial", Font.BOLD, 40));
        
        //set action listeners for buttons
        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        
        //add buttons to the frame
        //with spaces
        panel.add(Box.createRigidArea(new Dimension(0,200)));
        panel.add(button1);
        panel.add(Box.createRigidArea(new Dimension(0,30)));
        panel.add(button2);
        panel.add(Box.createRigidArea(new Dimension(0,30)));
        panel.add(button3);
        
        //add menu panel to frame, and make frame
        add(panel);
        pack();
        setVisible(true);
        setTitle("Bullet Box");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setTitle("Bullet Box");
        setSize(800, 600);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String action = ae.getActionCommand();
        if (action.equals("Level 1")) {
            level = new GameWindow(menu, this, 1);
            //set the other window to be visible
            level.setVisible(true);
            //hide this window
            this.setVisible(false);
        }
        if (action.equals("Level 2")) {
            level = new GameWindow(menu, this, 2);
            //set the other window to be visible
            level.setVisible(true);
            //hide this window
            this.setVisible(false);
        }
        if (action.equals("Level 3")) {
            level = new GameWindow(menu, this, 3);
            //set the other window to be visible
            level.setVisible(true);
            //hide this window
            this.setVisible(false);
        }
    }
}
