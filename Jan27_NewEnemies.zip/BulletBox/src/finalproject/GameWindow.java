package finalproject;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.*;

public class GameWindow extends JFrame {

    public static BulletBox menu;

    public GameWindow(BulletBox m, int level) {
        initUI(level);
        
        menu = m;
    }

    private void initUI(int level) {
        add(new Board(level));

        setTitle("Bullet Box");
        setSize(800, 600);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
    }

}
