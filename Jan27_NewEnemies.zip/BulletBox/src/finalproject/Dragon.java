/*
 * Nathan Smith 
 *January 26, 2022
 * Dragon class to create dragon objects
 */
package finalproject;

import java.net.URL;
import javax.swing.ImageIcon;

public class Dragon extends Enemy{
    private static URL url = Entity.class.getResource("dragon.png");
    private static ImageIcon ii = new ImageIcon(url);
    private int phase;
    private double initialAngle1, initialAngle2;
    private int frameDelay = 50, frameCounter, shotGap;
    
    public Dragon(double x, double y, int frameDelay){
        super(x,y,ii.getIconWidth(),ii.getIconHeight());
        imgPlayer = ii.getImage();
    }
    
    public void attack(){
        if (phase == 0){
            if (frameCounter <0){
                if (shotGap >= 4){
                    shotGap =0;
                } else {
                shotGap++;
                }
                for (int i = 0; i<4 ; i++){
                    if (shotGap != i){
                        projectiles.add(new Projectile(x,y,Math.cos(initialAngle1 + (Math.PI/2 * i)), Math.sin(initialAngle1 + (Math.PI/2 * i))));
                    }
                }
                 for (int i = 0; i<4; i++){
                    if (3 - shotGap != i){
                        projectiles.add(new Projectile(x,y,Math.cos(initialAngle2 + (Math.PI/2 * i)), Math.sin(initialAngle2 + (Math.PI/2 * i))));
                    }
                }
                initialAngle1+=Math.PI/18;
                initialAngle2-=Math.PI/18;
                frameCounter = frameDelay;
            } else {
                frameCounter--;
            }
        }
    }
    
}
