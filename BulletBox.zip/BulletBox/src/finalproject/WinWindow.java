//Alex, Lado, Nathan
//January 27 2022
//Death screen
package finalproject;

import static finalproject.GameWindow.menu;
import static finalproject.BulletBox.level;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

public class WinWindow extends JFrame implements ActionListener {
    

    private JButton home;
    private JButton searchButton;
    private SaveData[] saves;

    /**
     * Class to run a background image for a JFrame
     */
    class ImagePanel extends JComponent {





        /**
         * Paint the component
         * @param g - the graphics to paint with
         */
        @Override
        protected void paintComponent(Graphics g) {
            //invoke super method
            super.paintComponent(g);
            //draw the image
  
        }
    }

    /**
     * Primary Constructor
     * @param m - the bullet box menu
     */
    public WinWindow(BulletBox m, SaveData[] saves) {
        //create ui
        this.saves = saves;
        initUI();
        
        //assign menu
        menu = m;
    }

    /**
     * Create UI
     */
    private void initUI() {
        
        //set background image
       // JFrame.setDefaultLookAndFeelDecorated(true);


        //get image icon
        ImageIcon iconHome = new ImageIcon("src/finalproject/homeButton.jpg");
        //get the image from the icon
        Image img1 = iconHome.getImage();
        //resize image icon
        Image newimg1 = img1.getScaledInstance(200, 50, java.awt.Image.SCALE_SMOOTH);
        //get image home image
        iconHome = new ImageIcon(newimg1);
        //create home button
        home = new JButton(iconHome);
        searchButton = new JButton();
        //set home button background to black
        home.setBackground(Color.BLACK);
        //set home button to be opaque
        home.setOpaque(true);
        //add actionlistener to homebutton
        home.addActionListener(this);
        //set bounds for home button
        home.setBounds(300, 50, 2, 50);
        
        searchButton.addActionListener(this);
        searchButton.setBounds(50, 50, 100, 100);
        searchButton.setText("Sort");

         add(searchButton);

        
        TextField text = new TextField();
        text.setEnabled(false);
        text.setBounds(200, 50, 400, 300);
 
        //add home to JFrame
        add(text);
        add(home);
        
        pack();
        //set title
        setTitle("Bullet Box");
        //set dimensions
        setSize(800, 600);
        //set default close operation
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
    }

    /**
     * ActionEvent listener
     * @param e the ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == home) {
            //if menu does not exit
            if (menu == null) {
                //create new menu
                menu = new BulletBox();
            }
            //set menu to visible
            menu.setVisible(true);
            //hide this window
            this.dispose();
        }
        if (e.getSource() == searchButton){
            findScore(saves);
        }
    }
    
    private int findScore(SaveData[] saves){
        String name = JOptionPane.showInputDialog("Enter the name of a player:");
        int best = -1, index = -1;
        
        for (int i = 0; i<saves.length; i++){
            if (saves[i].getName().equals(name) && (saves[i].getScore() < best || best<0)){
                best = saves[i].getScore();
                index = i;
            }
        }
        return index;
    }
    
    
}
