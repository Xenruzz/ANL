package finalproject;

import static finalproject.BulletBox.State;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

public class MainMenu extends JPanel implements ActionListener {

    public MainMenu() throws IOException {
        initMenu();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private BufferedImage image;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.drawImage(image, 0, 0, this);

    }

    private void initMenu() {
        try {
            image = ImageIO.read(new File("D:\\Users\\ladon\\Documents\\NetBeansProjects\\BulletBox\\BulletBox\\src\\finalproject\\background.png"));
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

        JButton b1 = new JButton("Play");
        JButton b2 = new JButton("Tutorial");
        JButton b3 = new JButton("Exit");

        add(b1);
        add(b2);
        add(b3);

        b1.setVisible(true);
        b2.setVisible(true);
        b3.setVisible(true);
        
        b1.addActionListener((ActionEvent e) -> {
            System.out.println("214");
            BulletBox.State = STATE.GAME;
            System.out.println(State);
        });

        b2.addActionListener((ActionEvent e) -> {
            System.out.println("367");
            System.out.println(State);
        });

        b3.addActionListener((ActionEvent e) -> {
            System.exit(0);
        });
        
        this.setVisible(true);
    }

    public static void addComponentsToPane(JButton button, Container pane) {
        pane.setLayout(new BoxLayout(pane, BoxLayout.Y_AXIS));
        addAButton(button, pane);
    }

    private static void addAButton(JButton button, Container container) {
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("Arial", Font.BOLD, 40));
        container.add(button);
    }

}
