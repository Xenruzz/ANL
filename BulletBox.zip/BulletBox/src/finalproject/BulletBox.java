package finalproject;


import java.awt.EventQueue;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

enum STATE {
    MENU, GAME
}

public class BulletBox extends JFrame {
    
    public static STATE State = STATE.MENU;
    
    public BulletBox() throws IOException {
        initUI();
    }

    private void initUI() {
        if (State == STATE.MENU) {
            try {
                add(new MainMenu());
            } catch (IOException ex) {
                Logger.getLogger(BulletBox.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        if (State == STATE.GAME) {
            add(new Game());
        }

        setTitle("Bullet Box");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            BulletBox ex;
            try {
                ex = new BulletBox();
                ex.setVisible(true);
                if (State == STATE.MENU) {
                    
                }
            } catch (IOException ex1) {
                Logger.getLogger(BulletBox.class.getName()).log(Level.SEVERE, null, ex1);
            }
        });
    }

}
