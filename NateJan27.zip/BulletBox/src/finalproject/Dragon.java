/*
 * Nathan Smith 
 *January 26, 2022
 * Dragon class to create dragon objects
 */
package finalproject;

import java.net.URL;
import javax.swing.ImageIcon;

public class Dragon extends Enemy{
    private static URL url = Entity.class.getResource("dragon.png");
    private static ImageIcon ii = new ImageIcon(url);
    private int phase;
    private double initialAngle1, initialAngle2;
    private int frameDelay = 50, frameCounter, shotGap;
    private double chargeDirection, playerDirection;
    
    public Dragon(double x, double y, int frameDelay, int phase){
        super(x,y,ii.getIconWidth(),ii.getIconHeight());
        imgPlayer = ii.getImage();
        enemyType = 3;
        this.phase = phase;
    }
    
    public void attack(){
        if (phase == 0){
            if (frameCounter <=0){
                if (shotGap >= 4){
                    shotGap =0;
                } else {
                shotGap++;
                }
                for (int i = 0; i<4 ; i++){
                    if (shotGap != i){
                        projectiles.add(new Projectile(x + w/2,y + h/2,Math.cos(initialAngle1 + (Math.PI/2 * i)), Math.sin(initialAngle1 + (Math.PI/2 * i))));
                    }
                }
                 for (int i = 0; i<4; i++){
                    if (3 - shotGap != i){
                        projectiles.add(new Projectile(x + w/2,y + h/2,Math.cos(initialAngle2 + (Math.PI/2 * i)), Math.sin(initialAngle2 + (Math.PI/2 * i))));
                    }
                }
                initialAngle1+=Math.PI/18;
                initialAngle2-=Math.PI/18;
                frameCounter = frameDelay;
            } else {
                frameCounter--;
            }
        } else {
            
            if (frameCounter <= 0){
                projectiles.add(new Projectile(x + w/2,y + h/2, Math.cos(chargeDirection + Math.PI/2) * 2, Math.sin(chargeDirection + Math.PI/2) * 2));
                projectiles.add(new Projectile(x + w/2,y + h/2, Math.cos(chargeDirection - Math.PI/2) * 2, Math.sin(chargeDirection - Math.PI/2) * 2));
                frameCounter = frameDelay/2;
            } else {
                frameCounter--;
            } 
        }
    }
    
    public void chase(Player p, Level l){
        if (phase == 1){
            x = x + Math.cos(chargeDirection)*4;
            y = y + Math.sin(chargeDirection)*4; 
            hitX = hitX + Math.cos(chargeDirection)*4;
            hitY = hitY + Math.sin(chargeDirection)*4; 
            if (l.checkWall(this) == true){
                x = x - Math.cos(chargeDirection)*4;
                y = y - Math.sin(chargeDirection)*4; 
                hitX = hitX - Math.cos(chargeDirection)*4;
                hitY = hitY - Math.sin(chargeDirection)*4; 
                chargeDirection = Math.atan2(p.getY() - y,  p.getX() - x);
            }  
        }
    }
    
    public void switchPhase(){
        if (phase == 0){
            phase = 1;
        } else {
            phase = 0;
        }
    }
    
    public String toString(){
        return "Dragon: " + super.toString() + "Frame Delay: ";
    }
    
    public Dragon clone(){
        Dragon clone = new Dragon(x,y,frameDelay,phase);
        return clone;
    }
    
    public boolean equals(Dragon otherDragon){
        return (super.equals(otherDragon) && frameDelay == otherDragon.frameDelay);
    }
    
    
    
}
